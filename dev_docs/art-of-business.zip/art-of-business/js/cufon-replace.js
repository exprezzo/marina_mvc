Cufon.replace('h1, .text1, .text2, #icons, h2, .button, .submit', { fontFamily: 'Myriad Pro', hover:true });

