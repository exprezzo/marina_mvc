Side theme by NewWpThemes, http://newwpthemes.com
Online Demo: http://newwpthemes.com/demo/Side/
Theme URI: http://newwpthemes.com/side-free-wordpress-theme/