Cufon.replace('#header .row-1 .fright ul li, h3, h4', { fontFamily: 'Myriad Pro Regular' });
Cufon.replace('.box h3', { fontFamily: 'Myriad Pro Semibold', textShadow:'1px 1px #bd3400' });