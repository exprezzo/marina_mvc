ANIMALS by Dmitri Joukov

This set was inspired by the world of nature - a set of icons titled 
Animals. Why that happened and who's the one to blame - we can't tell. 
But we sincerely believe that no animals suffered in the process. 
Now we have no reason to buy expensive tickets to the zoo. Iconic 
animals are no worse than the real ones and come for free. 

This Animals icon pack is free to use for personal non-commercial purposes. 

Please give credits to http://www.turbomilk.com in case of public use. 
We sincerely hope that these icons will make you happy and nobody 
get hurt.

With Love, TurboMilk team.  

Release date: 24/05/2007
http://www.turbomilk.com
info@turbomilk.com